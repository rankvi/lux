/*
 * Lux Chauffeur — site-wide vanilla JS.
 * No framework, no build step. Two jobs only:
 *   1. Add/remove the "scrolled" look on the fixed header.
 *   2. Open/close the mobile menu.
 * Everything else on the site (desktop dropdowns, FAQ/process accordions)
 * is plain CSS or native <details>, so there is nothing to wire up for them.
 */
(function () {
  "use strict";

  var header = document.getElementById("site-header");
  if (header) {
    var scrolledClasses = (header.getAttribute("data-scrolled-class") || "").split(" ").filter(Boolean);
    var topClasses = (header.getAttribute("data-top-class") || "").split(" ").filter(Boolean);

    function updateHeader() {
      var isScrolled = window.scrollY > 24;
      if (isScrolled) {
        topClasses.forEach(function (c) { header.classList.remove(c); });
        scrolledClasses.forEach(function (c) { header.classList.add(c); });
      } else {
        scrolledClasses.forEach(function (c) { header.classList.remove(c); });
        topClasses.forEach(function (c) { header.classList.add(c); });
      }
    }

    updateHeader();
    window.addEventListener("scroll", updateHeader, { passive: true });
  }

  var menuBtn = document.getElementById("mobile-menu-btn");
  var menu = document.getElementById("mobile-menu");
  var iconOpen = document.getElementById("mobile-menu-icon-open");
  var iconClose = document.getElementById("mobile-menu-icon-close");

  if (menuBtn && menu) {
    menuBtn.addEventListener("click", function () {
      var isHidden = menu.classList.contains("hidden");
      menu.classList.toggle("hidden");
      menuBtn.setAttribute("aria-expanded", isHidden ? "true" : "false");
      if (iconOpen && iconClose) {
        iconOpen.classList.toggle("hidden");
        iconClose.classList.toggle("hidden");
      }
    });

    // Close the mobile menu automatically after tapping a link in it.
    menu.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        menu.classList.add("hidden");
        menuBtn.setAttribute("aria-expanded", "false");
        if (iconOpen && iconClose) {
          iconOpen.classList.remove("hidden");
          iconClose.classList.add("hidden");
        }
      });
    });
  }
})();
