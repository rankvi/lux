/*
 * Lux Chauffeur — /book-now/ booking wizard.
 * The <form> is a normal HTML form that works with JS disabled (every field
 * is visible and it posts straight to /send-message.php). This script only
 * adds the step-by-step "Route -> Vehicle -> Your Details" look, and
 * prefills pickup/dropoff/date from the homepage quick-quote bar's URL
 * parameters (?pickup=...&dropoff=...&date=...).
 */
(function () {
  "use strict";

  var wizard = document.querySelector("[data-booking-wizard]");
  if (!wizard) return;

  var form = wizard.querySelector("[data-booking-form]");
  var steps = Array.prototype.slice.call(wizard.querySelectorAll("[data-step]"));
  if (!steps.length) return;

  var current = 1;

  function render() {
    steps.forEach(function (stepEl) {
      var num = parseInt(stepEl.getAttribute("data-step"), 10);
      stepEl.classList.toggle("hidden", num !== current);
    });

    wizard.querySelectorAll("[data-indicator-circle]").forEach(function (el) {
      var num = parseInt(el.getAttribute("data-indicator-circle"), 10);
      var active = num <= current;
      el.classList.toggle("bronze-gradient", active);
      el.classList.toggle("text-ink", active);
      el.classList.toggle("border", !active);
      el.classList.toggle("border-line", !active);
      el.classList.toggle("text-muted", !active);
      el.textContent = num < current ? "✓" : String(num);
    });
    wizard.querySelectorAll("[data-indicator-label]").forEach(function (el) {
      var num = parseInt(el.getAttribute("data-indicator-label"), 10);
      el.classList.toggle("text-white", num <= current);
      el.classList.toggle("text-muted", num > current);
    });
    wizard.querySelectorAll("[data-indicator-bar]").forEach(function (el) {
      var num = parseInt(el.getAttribute("data-indicator-bar"), 10);
      el.classList.toggle("bg-bronze", num < current);
      el.classList.toggle("bg-line", num >= current);
    });
  }

  // A <div data-step="…"> is not a form control, so it has no
  // checkValidity()/reportValidity() of its own — only the inputs, selects
  // and textareas inside it do. Validate those directly instead.
  function stepIsValid(stepEl) {
    var controls = stepEl.querySelectorAll("input, select, textarea");
    for (var i = 0; i < controls.length; i += 1) {
      if (!controls[i].checkValidity()) {
        controls[i].reportValidity();
        return false;
      }
    }
    return true;
  }

  wizard.querySelectorAll("[data-next-step]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var currentStepEl = wizard.querySelector('[data-step="' + current + '"]');
      if (currentStepEl && !stepIsValid(currentStepEl)) {
        return;
      }
      if (current < steps.length) {
        current += 1;
        render();
      }
    });
  });

  wizard.querySelectorAll("[data-prev-step]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (current > 1) {
        current -= 1;
        render();
      }
    });
  });

  render();

  // Prefill from ?pickup=&dropoff=&date= (set by the homepage quick-quote bar).
  if (form) {
    var params = new URLSearchParams(window.location.search);
    form.querySelectorAll("[data-prefill]").forEach(function (input) {
      var key = input.getAttribute("data-prefill");
      var value = params.get(key);
      if (value) input.value = value;
    });

    // The homepage quick-quote bar only asks for pickup + dropoff, so if
    // both arrived pre-filled, step 1 is already complete — skip straight
    // to Vehicle Selection instead of making the visitor re-submit it.
    if (params.get("pickup") && params.get("dropoff") && current === 1) {
      current = 2;
      render();
    }
  }
})();
