<?php
/**
 * Lux Chauffeur — contact & booking form handler for Hostinger.
 *
 * Every enquiry form on the static site posts here with three hidden
 * fields: form_source (which form it was), redirect (which thank-you page
 * to send the visitor to), and company_website (a honeypot — real visitors
 * never fill it in, so if it has a value we quietly drop the message).
 *
 * SETUP (only thing you need to change):
 *   1. Set TO_EMAIL below to the inbox that should receive enquiries.
 *   2. Upload this file to the root of your Hostinger hosting, next to
 *      index.html, so its URL is https://luxchauffeur.co.uk/send-message.php
 *
 * Hostinger's built-in mail() usually works out of the box. If enquiries
 * are not arriving, ask Hostinger support to confirm mail() is enabled for
 * your plan, or switch this script to SMTP (PHPMailer) instead — the
 * validation and redirect logic below stays exactly the same either way.
 */

// ---- 1. Configuration -----------------------------------------------------

$TO_EMAIL = "info@luxchauffeur.co.uk";
$SITE_NAME = "Lux Chauffeur";
$ALLOWED_REDIRECTS = ["/contact-thank-you/", "/book-thank-you/"];

// ---- 2. Basic request checks ------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: /");
    exit;
}

function field($name, $maxLength = 2000)
{
    $value = isset($_POST[$name]) ? trim((string) $_POST[$name]) : "";
    $value = substr($value, 0, $maxLength);
    // Strip anything that could be used for email header injection.
    $value = str_replace(["\r", "\n"], " ", $value);
    return $value;
}

// Honeypot: bots fill every field, real visitors never see this one.
if (field("company_website") !== "") {
    exit; // Silently drop — no error, no email, nothing for a bot to learn from.
}

$name = field("name", 120);
$phone = field("phone", 40);
$email = field("email", 160);
$pickup = field("pickup", 200);
$dropoff = field("dropoff", 200);
$travelDate = field("travelDate", 40);
$travelTime = field("travelTime", 40);
$passengers = field("passengers", 40);
$vehicle = field("vehicle", 80);
$message = field("message", 3000);
$formSource = field("form_source", 80);
$redirect = field("redirect", 100);

if (!in_array($redirect, $ALLOWED_REDIRECTS, true)) {
    $redirect = "/contact-thank-you/";
}

$errors = [];
if ($name === "") $errors[] = "name";
if ($phone === "") $errors[] = "phone";

if (!empty($errors)) {
    // Missing required fields — send the visitor back rather than losing
    // their input silently.
    header("Location: /contact-us/?error=missing_fields");
    exit;
}

if ($email !== "" && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $email = ""; // Drop an invalid email rather than failing the whole enquiry.
}

// ---- 3. Build and send the email ------------------------------------------

$subject = "New enquiry from $SITE_NAME website ($formSource)";

$bodyLines = [
    "New enquiry received via $SITE_NAME website",
    "Form: $formSource",
    "-----------------------------------",
    "Name: $name",
    "Phone: $phone",
    "Email: " . ($email !== "" ? $email : "(not provided)"),
    "Pickup: " . ($pickup !== "" ? $pickup : "(not provided)"),
    "Drop-off: " . ($dropoff !== "" ? $dropoff : "(not provided)"),
    "Travel date: " . ($travelDate !== "" ? $travelDate : "(not provided)"),
    "Travel time: " . ($travelTime !== "" ? $travelTime : "(not provided)"),
    "Passengers: " . ($passengers !== "" ? $passengers : "(not provided)"),
    "Vehicle preference: " . ($vehicle !== "" ? $vehicle : "(not provided)"),
    "Message:",
    $message !== "" ? $message : "(none)",
];
$body = implode("\n", $bodyLines);

// Deliverability note: the previous version sent "From: no-reply@…" without
// telling PHP's mail() which mailbox to use as the envelope sender. On
// shared hosting that usually leaves the envelope sender as something like
// "www-data@server-hostname", which does not match luxchauffeur.co.uk's SPF
// record — that mismatch is the single biggest reason these enquiries were
// landing in spam. Sending From/envelope-sender as $TO_EMAIL (a real,
// existing mailbox on this domain) instead fixes the SPF alignment.
$headers = [];
$headers[] = "From: $SITE_NAME Website <$TO_EMAIL>";
$headers[] = "Return-Path: $TO_EMAIL";
if ($email !== "") {
    $headers[] = "Reply-To: $email";
}
$headers[] = "MIME-Version: 1.0";
$headers[] = "Content-Type: text/plain; charset=UTF-8";

// The 5th argument sets the envelope sender ("-f") to the same address, so
// it lines up with the visible From header above.
@mail($TO_EMAIL, $subject, $body, implode("\r\n", $headers), "-f$TO_EMAIL");

// ---- 4. Redirect to the matching thank-you page ---------------------------
// This page is not linked anywhere on the site, so this redirect is the
// only way to reach it — every pageview there is a real form submission,
// safe to use as a Google Analytics 4 conversion goal.

header("Location: " . $redirect);
exit;
